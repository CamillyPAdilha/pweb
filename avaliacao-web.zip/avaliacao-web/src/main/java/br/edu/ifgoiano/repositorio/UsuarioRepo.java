package br.edu.ifgoiano.repositorio;

import org.springframework.data.jpa.repository.JpaRepository;

import br.edu.ifgoiano.entidade.Usuario;

public interface UsuarioRepo extends JpaRepository<Usuario, Long>{

}
