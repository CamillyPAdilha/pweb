package br.edu.ifgoiano.controle;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import br.edu.ifgoiano.entidade.Usuario;
import br.edu.ifgoiano.repositorio.UsuarioRepo;

@Controller
public class LoginController {

	@Autowired
	private UsuarioRepo usuarioRepo;
	
	@GetMapping(value = "/login")
	public String abrirLogin()
	{
		return "login.html";
	}
	
	@PostMapping(value = "/entrar")
	public String logar(Usuario usuario)
	{
		usuarioRepo.save(usuario);

		return "login.html";
	}

}
