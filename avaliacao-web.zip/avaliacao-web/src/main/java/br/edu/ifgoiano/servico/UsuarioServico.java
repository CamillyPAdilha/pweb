package br.edu.ifgoiano.servico;

import java.util.List;

import br.edu.ifgoiano.entidade.Usuario;

public interface UsuarioServico {

	public List<Usuario> listarUsuario();
}
