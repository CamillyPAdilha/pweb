package br.edu.ifgoiano.servico;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import br.edu.ifgoiano.entidade.Usuario;
import br.edu.ifgoiano.repositorio.UsuarioRepo;

public class UsuarioServicoImpl	implements UsuarioServico {

	@Autowired
	private UsuarioRepo usuarioRepo;

	public List<Usuario> listarUsuario() {
		return usuarioRepo.findAll();
	}

}
